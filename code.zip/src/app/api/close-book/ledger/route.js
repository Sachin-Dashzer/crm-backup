import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import connectDB from "@/lib/db";
import Transactions from "@/models/Transactions";
import { ACCOUNTS } from "@/constants/bankRouting";
import {
  buildBalanceMatch,
  buildContraLedgerUnionStage,
  buildSuspenseLedgerUnionStage,
  SIGNED_AMOUNT,
  getOpeningBalance,
  round2,
} from "@/lib/accountBalances";

const ALLOWED_ROLES = ["admin", "super-admin"];

// Account ledger: opening balance, every movement in the period in chronological order with
// a RUNNING BALANCE, and the closing balance.
//
// ONE aggregation does all of it. The running balance is computed with $setWindowFields
// BEFORE $skip/$limit, so page 3 shows the true cumulative balance rather than restarting
// from zero — paginating first and summing in JS would have silently produced a wrong
// running column on every page but the first.
//
// Deliberately not modelled on /api/transactions/get-data, which fetches everything and
// reduces in JS.
export async function GET(request) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    if (!ALLOWED_ROLES.includes(session.user.role)) {
      return NextResponse.json({ error: "Forbidden — admin access required" }, { status: 403 });
    }

    await connectDB();

    const { searchParams } = new URL(request.url);
    const account = searchParams.get("account") || "";
    const from = searchParams.get("from") || "";
    const to = searchParams.get("to") || "";
    const transactionCategory = searchParams.get("transactionCategory") || "";
    const method = searchParams.get("method") || "";
    const branch = searchParams.get("branch") || "";
    const page = Math.max(1, parseInt(searchParams.get("page") || "1"));
    const limit = Math.min(200, Math.max(1, parseInt(searchParams.get("limit") || "50")));

    if (!ACCOUNTS.includes(account)) {
      return NextResponse.json(
        { error: `account is required and must be one of: ${ACCOUNTS.join(", ")}` },
        { status: 400 },
      );
    }
    if (!from || !to) {
      return NextResponse.json({ error: "from and to dates are required" }, { status: 400 });
    }

    const match = buildBalanceMatch({
      account,
      from,
      to,
      transactionCategory,
      method,
      branch,
    });

    const started = Date.now();

    // Internal transfers are folded in as ordinary ledger rows so a contra entry is visible
    // from BOTH sides: the same 10,000 shows as an outflow in the source account's ledger and
    // an inflow in the destination's. Without this the ledger's closing balance also silently
    // disagreed with the balance sheet's for the same account and period, since that side has
    // always unioned contra in. Null under a branch/category/method filter — see the helper.
    const contraStage = buildContraLedgerUnionStage({
      account,
      from,
      to,
      branch,
      transactionCategory,
      method,
    });

    // Unexplained bank movement, folded in the same way. Only OPEN entries — a resolved one has
    // a real transaction carrying its money, already counted above.
    const suspenseStage = buildSuspenseLedgerUnionStage({
      account,
      from,
      to,
      branch,
      transactionCategory,
      method,
    });

    const [opening, [result]] = await Promise.all([
      // Branch-filtered views open from that branch's own seed, not the company figure — see
      // getOpeningBalance. Unseeded branches open at 0 and the UI says so.
      getOpeningBalance(account, from, branch || null),
      Transactions.aggregate([
        { $match: match },
        {
          $addFields: {
            signedAmount: SIGNED_AMOUNT,
            isContra: { $literal: false },
            isSuspense: { $literal: false },
          },
        },
        ...(contraStage ? [contraStage] : []),
        ...(suspenseStage ? [suspenseStage] : []),
        // Cumulative running total across the WHOLE filtered period, computed before
        // pagination. _id breaks ties so same-day rows have a stable, repeatable order.
        {
          $setWindowFields: {
            sortBy: { date: 1, _id: 1 },
            output: {
              runningDelta: {
                $sum: "$signedAmount",
                window: { documents: ["unbounded", "current"] },
              },
            },
          },
        },
        {
          $facet: {
            rows: [
              { $skip: (page - 1) * limit },
              { $limit: limit },
              {
                $project: {
                  date: 1,
                  transactionCategory: 1,
                  costType: 1,
                  amount: 1,
                  signedAmount: 1,
                  runningDelta: 1,
                  method: 1,
                  branch: 1,
                  furtherMode: 1,
                  receiptMode: 1,
                  procedure: 1,
                  expense: 1,
                  expenseType: 1,
                  patientName: 1,
                  paymentId: 1,
                  remarks: 1,
                  // Contra / suspense-only fields; absent on transaction rows.
                  isContra: 1,
                  isSuspense: 1,
                  fromAccount: 1,
                  toAccount: 1,
                  direction: 1,
                  reference: 1,
                },
              },
            ],
            summary: [
              {
                $group: {
                  _id: null,
                  // Direction is read off signedAmount rather than costType so contra rows —
                  // which have no costType — total correctly alongside ordinary movements.
                  // Equivalent to the previous costType test for every row with a positive
                  // amount, which is every real row.
                  totalIn: {
                    $sum: { $cond: [{ $gt: ["$signedAmount", 0] }, "$signedAmount", 0] },
                  },
                  totalOut: {
                    $sum: {
                      $cond: [{ $lt: ["$signedAmount", 0] }, { $abs: "$signedAmount" }, 0],
                    },
                  },
                  transactionCount: {
                    $sum: { $cond: [{ $or: ["$isContra", "$isSuspense"] }, 0, 1] },
                  },
                  contraCount: { $sum: { $cond: ["$isContra", 1, 0] } },
                  suspenseCount: { $sum: { $cond: ["$isSuspense", 1, 0] } },
                },
              },
            ],
          },
        },
      ]).allowDiskUse(true),
    ]);

    const elapsedMs = Date.now() - started;

    const summary = result?.summary?.[0] || {
      totalIn: 0,
      totalOut: 0,
      transactionCount: 0,
      contraCount: 0,
      suspenseCount: 0,
    };
    const openingBalance = round2(opening.openingBalance);
    const totalIn = round2(summary.totalIn);
    const totalOut = round2(summary.totalOut);
    const closingBalance = round2(openingBalance + totalIn - totalOut);
    // Pagination counts every ROW the ledger renders, contra included — counting only
    // transactions would drop the last page's worth of rows once transfers exist.
    const movementCount =
      summary.transactionCount + summary.contraCount + (summary.suspenseCount || 0);

    // runningDelta is cumulative movement; the displayed running balance starts from the
    // opening balance. closingBalance therefore always equals the last row's running
    // balance — asserted by the verification script.
    const rows = (result?.rows || []).map((r) => ({
      ...r,
      runningBalance: round2(openingBalance + r.runningDelta),
    }));

    return NextResponse.json({
      success: true,
      account,
      period: { from, to },
      openingBalance,
      openingBalanceSeeded: opening.seeded,
      // How the opening figure was arrived at: the anchored number, plus everything that has
      // moved since it. Surfaced so the UI can explain a balance nobody typed in.
      openingAnchorBalance: opening.anchorBalance ?? openingBalance,
      openingCarriedForward: opening.carriedForward ?? 0,
      totalIn,
      totalOut,
      closingBalance,
      transactionCount: summary.transactionCount,
      contraCount: summary.contraCount,
      suspenseCount: summary.suspenseCount || 0,
      movementCount,
      // True when a filter suppressed contra entries, so the UI can say the ledger won't
      // reconcile with the unfiltered view rather than leaving the gap unexplained.
      contraExcludedByFilter: !contraStage,
      rows,
      pagination: {
        page,
        limit,
        total: movementCount,
        totalPages: Math.max(1, Math.ceil(movementCount / limit)),
      },
      elapsedMs,
    });
  } catch (error) {
    console.error("Error building account ledger:", error);
    return NextResponse.json({ error: "Failed to build account ledger" }, { status: 500 });
  }
}
