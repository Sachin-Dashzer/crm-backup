/**
 * import-contra-entries-april.js
 *
 * Self-contained import of the April contra entries into the AccountTransfer collection.
 * Data is embedded below - no Excel or JSON file needed at runtime.
 *
 * DRY RUN by default. Nothing is written until you pass --apply.
 *
 *   node scripts/import-contra-entries-april.js            # preview
 *   node scripts/import-contra-entries-april.js --apply    # write
 *
 * Source: contra-entries_active_2026-08-12.xlsx
 *   64 rows, Rs 24,62,600 moved, 6-30 April 2026, all Delhi branch, all Active.
 *
 * NET EFFECT PER ACCOUNT (this is the whole point of the import):
 *     HDFC Skin       +7,71,300
 *     ICICI Medihub   -5,96,000
 *     HDFC Medihub    -1,75,300
 *     ----------------------------
 *     NET SUM                  0
 *
 * That zero is the invariant. A contra entry moves money between our own accounts and can
 * never change the total cash position. The script asserts it before writing and aborts if
 * it is ever non-zero, because a non-zero sum means a sign error somewhere and would corrupt
 * every account balance downstream.
 *
 * SHEET COLUMNS NOT IMPORTED, and why:
 *   Status ("Active" on all 64)      - the model's field is `isCancelled`; Active maps to false
 *   Moves balances ("Yes" on all 64) - not a stored field; every non-cancelled transfer moves
 *                                      balances by definition
 *   Recorded by ("Admin" on all 64)  - createdBy is set to the bulk-import identity instead,
 *                                      so imported rows are distinguishable from hand-entered ones
 *
 * All From/To values matched the ACCOUNTS constant exactly - no remapping was needed.
 * The Reference column is empty throughout; the IMPS strings live in Remarks and are kept there.
 */

import mongoose from "mongoose";
import fs from "fs";
// import dotenv from "dotenv";
import { ACCOUNTS } from "../src/constants/bankRouting.js";
import { ALL_BRANCHES } from "../src/lib/branches.js";

// dotenv.config({ path: ".env.local" });

// ---------------------------------------------------------------------------
// Embedded data - 64 rows
// ---------------------------------------------------------------------------
const ENTRIES = [
  { rowNum: 2, date: "2026-04-06", fromAccount: "HDFC Medihub", toAccount: "ICICI Medihub", amount: 55000, branch: "Delhi", reference: "", remarks: "IMPS-609645024194-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 3, date: "2026-04-14", fromAccount: "HDFC Medihub", toAccount: "ICICI Medihub", amount: 53900, branch: "Delhi", reference: "", remarks: "IMPS-610448569581-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 4, date: "2026-04-22", fromAccount: "HDFC Medihub", toAccount: "ICICI Medihub", amount: 17500, branch: "Delhi", reference: "", remarks: "IMPS-611251722294-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 5, date: "2026-04-27", fromAccount: "HDFC Medihub", toAccount: "ICICI Medihub", amount: 48900, branch: "Delhi", reference: "", remarks: "IMPS-611753560760-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 6, date: "2026-04-06", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 75000, branch: "Delhi", reference: "", remarks: "IMPS-609610747833-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 7, date: "2026-04-06", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 14000, branch: "Delhi", reference: "", remarks: "IMPS-609614511638-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 8, date: "2026-04-06", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 1500, branch: "Delhi", reference: "", remarks: "IMPS-609615721664-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 9, date: "2026-04-07", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 30000, branch: "Delhi", reference: "", remarks: "IMPS-609717331513-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 10, date: "2026-04-10", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 30000, branch: "Delhi", reference: "", remarks: "IMPS-610016853774-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 11, date: "2026-04-12", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 46000, branch: "Delhi", reference: "", remarks: "IMPS-610214983945-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 12, date: "2026-04-12", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 48000, branch: "Delhi", reference: "", remarks: "IMPS-610217202109-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 13, date: "2026-04-12", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 200000, branch: "Delhi", reference: "", remarks: "IMPS-610219425855-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 14, date: "2026-04-14", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 13000, branch: "Delhi", reference: "", remarks: "IMPS-610411097783-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 15, date: "2026-04-14", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 17800, branch: "Delhi", reference: "", remarks: "IMPS-610416626863-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 16, date: "2026-04-17", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 17700, branch: "Delhi", reference: "", remarks: "IMPS-610719599591-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 17, date: "2026-04-18", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 11000, branch: "Delhi", reference: "", remarks: "IMPS-610816910111-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 18, date: "2026-04-19", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 23900, branch: "Delhi", reference: "", remarks: "IMPS-610918402935-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 19, date: "2026-04-20", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 10000, branch: "Delhi", reference: "", remarks: "IMPS-611010052594-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 20, date: "2026-04-20", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 9500, branch: "Delhi", reference: "", remarks: "IMPS-611017965987-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 21, date: "2026-04-20", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 19000, branch: "Delhi", reference: "", remarks: "IMPS-611018034847-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 22, date: "2026-04-21", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 20000, branch: "Delhi", reference: "", remarks: "IMPS-611111957978-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 23, date: "2026-04-21", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 49800, branch: "Delhi", reference: "", remarks: "IMPS-611114415112-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 24, date: "2026-04-21", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 12600, branch: "Delhi", reference: "", remarks: "IMPS-611117710320-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 25, date: "2026-04-22", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 22000, branch: "Delhi", reference: "", remarks: "NEFT CR-ICIC0SF0002-RYAN MEDIHUB PRIVATE LIMITED-RYAN SKIN AND HAIR TRANSPLANT CLINIC-IN42611251111011" },
  { rowNum: 26, date: "2026-04-22", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 20000, branch: "Delhi", reference: "", remarks: "IMPS-611217430161-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 27, date: "2026-04-22", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 10000, branch: "Delhi", reference: "", remarks: "IMPS-611223977316-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 28, date: "2026-04-23", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 70700, branch: "Delhi", reference: "", remarks: "IMPS-611317172735-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 29, date: "2026-04-24", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 20000, branch: "Delhi", reference: "", remarks: "IMPS-611415774929-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 30, date: "2026-04-24", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 45000, branch: "Delhi", reference: "", remarks: "IMPS-611417961100-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 31, date: "2026-04-25", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 13000, branch: "Delhi", reference: "", remarks: "IMPS-611512061347-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 32, date: "2026-04-25", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 23000, branch: "Delhi", reference: "", remarks: "IMPS-611514206491-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 33, date: "2026-04-25", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 8900, branch: "Delhi", reference: "", remarks: "IMPS-611518625084-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 34, date: "2026-04-27", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 67000, branch: "Delhi", reference: "", remarks: "IMPS-611711709297-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 35, date: "2026-04-27", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 20000, branch: "Delhi", reference: "", remarks: "IMPS-611712812663-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 36, date: "2026-04-27", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 60000, branch: "Delhi", reference: "", remarks: "IMPS-611712854420-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 37, date: "2026-04-27", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 30000, branch: "Delhi", reference: "", remarks: "IMPS-611715136707-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 38, date: "2026-04-27", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 52000, branch: "Delhi", reference: "", remarks: "IMPS-611718506009-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 39, date: "2026-04-28", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 42000, branch: "Delhi", reference: "", remarks: "IMPS-611815977631-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 40, date: "2026-04-29", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 300000, branch: "Delhi", reference: "", remarks: "IMPS-611913678165-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 41, date: "2026-04-29", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 28000, branch: "Delhi", reference: "", remarks: "IMPS-611917088083-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 42, date: "2026-04-30", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 8000, branch: "Delhi", reference: "", remarks: "IMPS-612012508517-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 43, date: "2026-04-30", fromAccount: "ICICI Medihub", toAccount: "HDFC Skin", amount: 40900, branch: "Delhi", reference: "", remarks: "IMPS-612018462120-RYAN MEDIHUB PRIVATE-ICIC-XXXXXXXX0292-RYAN" },
  { rowNum: 44, date: "2026-04-09", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 5000, branch: "Delhi", reference: "", remarks: "IMPS-609946811855-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 45, date: "2026-04-11", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 15000, branch: "Delhi", reference: "", remarks: "IMPS-610147435540-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 46, date: "2026-04-12", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 23000, branch: "Delhi", reference: "", remarks: "IMPS-610247891652-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 47, date: "2026-04-12", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 70000, branch: "Delhi", reference: "", remarks: "IMPS-610247904115-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 48, date: "2026-04-13", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 25000, branch: "Delhi", reference: "", remarks: "IMPS-610348324223-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 49, date: "2026-04-15", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 34000, branch: "Delhi", reference: "", remarks: "IMPS-610548907808-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 50, date: "2026-04-19", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 100000, branch: "Delhi", reference: "", remarks: "IMPS-610950557831-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 51, date: "2026-04-19", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 15000, branch: "Delhi", reference: "", remarks: "IMPS-610950597427-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 52, date: "2026-04-20", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 4000, branch: "Delhi", reference: "", remarks: "IMPS-611050806275-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 53, date: "2026-04-20", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 40000, branch: "Delhi", reference: "", remarks: "IMPS-611050908668-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 54, date: "2026-04-21", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 70000, branch: "Delhi", reference: "", remarks: "IMPS-611151233414-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 55, date: "2026-04-21", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 56000, branch: "Delhi", reference: "", remarks: "IMPS-611151324717-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 56, date: "2026-04-22", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 15000, branch: "Delhi", reference: "", remarks: "IMPS-611251682842-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 57, date: "2026-04-23", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 55000, branch: "Delhi", reference: "", remarks: "IMPS-611352058979-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 58, date: "2026-04-24", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 50000, branch: "Delhi", reference: "", remarks: "IMPS-611452382396-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 59, date: "2026-04-24", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 20000, branch: "Delhi", reference: "", remarks: "IMPS-611452466349-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 60, date: "2026-04-24", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 20000, branch: "Delhi", reference: "", remarks: "IMPS-611452467072-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 61, date: "2026-04-26", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 7000, branch: "Delhi", reference: "", remarks: "IMPS-611653074553-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 62, date: "2026-04-26", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 50000, branch: "Delhi", reference: "", remarks: "IMPS-611653137772-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 63, date: "2026-04-26", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 12000, branch: "Delhi", reference: "", remarks: "IMPS-611653169306-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 64, date: "2026-04-27", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 2000, branch: "Delhi", reference: "", remarks: "IMPS-611753499996-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
  { rowNum: 65, date: "2026-04-29", fromAccount: "HDFC Skin", toAccount: "ICICI Medihub", amount: 70000, branch: "Delhi", reference: "", remarks: "IMPS-611954337221-RYAN MEDIHUB PRIVATE LIMITED-ICIC-XXXXXXXX0292-IMPS TRANSACTION" },
];

// ---------------------------------------------------------------------------
const args = process.argv.slice(2);
const APPLY = args.includes("--apply");
const ALLOW_DUPES = args.includes("--allow-duplicates");

const MONGODB_URI = "mongodb://sachindashzer:user8520@ac-pu86ixj-shard-00-00.hwjor1r.mongodb.net:27017,ac-pu86ixj-shard-00-01.hwjor1r.mongodb.net:27017,ac-pu86ixj-shard-00-02.hwjor1r.mongodb.net:27017/?ssl=true&replicaSet=atlas-ool7b4-shard-0&authSource=admin&appName=crm";
if (!MONGODB_URI) {
  console.error("MONGODB_URI missing in .env.local");
  process.exit(1);
}

// Minimal schema, strict:false - avoids importing the real model (which uses "@/" path
// aliases that a plain node script cannot resolve) while writing the same shape.
const AccountTransfer =
  mongoose.models.AccountTransfer ||
  mongoose.model(
    "AccountTransfer",
    new mongoose.Schema({}, { strict: false, collection: "accounttransfers" })
  );

const inr = (n) => "Rs " + Number(n).toLocaleString("en-IN", { maximumFractionDigits: 2 });

// ---------------------------------------------------------------------------
// Validation - everything checked before anything is written. A partial import of
// financial data is worse than no import, so one bad row aborts the whole run.
// ---------------------------------------------------------------------------
function validate(entries) {
  const errors = [];
  for (const e of entries) {
    const where = `row ${e.rowNum}`;
    if (!ACCOUNTS.includes(e.fromAccount))
      errors.push(`${where}: fromAccount "${e.fromAccount}" is not in ACCOUNTS (src/constants/bankRouting.js)`);
    if (!ACCOUNTS.includes(e.toAccount))
      errors.push(`${where}: toAccount "${e.toAccount}" is not in ACCOUNTS`);
    if (e.fromAccount === e.toAccount)
      errors.push(`${where}: from and to are the same account ("${e.fromAccount}")`);
    if (e.branch && !ALL_BRANCHES.includes(e.branch))
      errors.push(`${where}: unknown branch "${e.branch}"`);
    if (!(e.amount > 0))
      errors.push(`${where}: amount must be > 0 (got ${e.amount})`);
    if (isNaN(new Date(e.date).getTime()))
      errors.push(`${where}: bad date "${e.date}"`);
  }
  return errors;
}

// Net effect per account. The sum across accounts MUST be zero.
function netByAccount(entries) {
  const net = {};
  for (const e of entries) {
    net[e.fromAccount] = (net[e.fromAccount] || 0) - e.amount;
    net[e.toAccount] = (net[e.toAccount] || 0) + e.amount;
  }
  return net;
}

// ---------------------------------------------------------------------------
async function run() {
  const total = ENTRIES.reduce((s, e) => s + e.amount, 0);

  console.log("=".repeat(78));
  console.log(APPLY ? "MODE: APPLY  <- will write to the database" : "MODE: DRY RUN  <- nothing will be written");
  console.log(`Rows: ${ENTRIES.length}   Total moved: ${inr(total)}`);
  console.log("=".repeat(78) + "\n");

  const errors = validate(ENTRIES);
  if (errors.length) {
    console.error(`VALIDATION FAILED - ${errors.length} problem(s). Nothing imported.\n`);
    errors.slice(0, 25).forEach((e) => console.error("  " + e));
    if (errors.length > 25) console.error(`  ...and ${errors.length - 25} more`);
    process.exit(1);
  }
  console.log("Validation passed - all accounts, branches, amounts and dates are valid.\n");

  // --- the invariant check ---
  const net = netByAccount(ENTRIES);
  const netSum = Object.values(net).reduce((a, b) => a + b, 0);

  console.log("--- NET EFFECT BY ACCOUNT ---");
  Object.entries(net)
    .sort((a, b) => b[1] - a[1])
    .forEach(([acc, v]) => {
      const sign = v >= 0 ? "+" : "-";
      console.log(`  ${acc.padEnd(20)} ${sign}${inr(Math.abs(v))}`);
    });
  console.log(`  ${"NET SUM".padEnd(20)} ${inr(netSum)}`);

  if (Math.abs(netSum) > 0.005) {
    console.error(`\nABORTING - net sum is ${netSum}, not zero.`);
    console.error(`A contra entry moves money between own accounts and cannot change the total.`);
    console.error(`A non-zero sum means a sign error, and importing it would corrupt every balance.`);
    process.exit(1);
  }
  console.log("  (zero as required - contra entries never change the total cash position)\n");

  await mongoose.connect(MONGODB_URI, { serverSelectionTimeoutMS: 5000 });

  // --- duplicate guard, batched by date so 64 rows are not 64 round trips ---
  console.log("Checking for already-imported rows...");
  const dupes = [];
  const byDate = new Map();
  ENTRIES.forEach((e) => {
    if (!byDate.has(e.date)) byDate.set(e.date, []);
    byDate.get(e.date).push(e);
  });

  for (const [dateStr, group] of byDate) {
    const d = new Date(dateStr);
    const dayStart = new Date(d); dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(d); dayEnd.setHours(23, 59, 59, 999);

    const existing = await AccountTransfer.find({
      date: { $gte: dayStart, $lte: dayEnd },
    }).select("fromAccount toAccount amount remarks").lean();

    const seen = new Map();
    existing.forEach((x) => {
      seen.set(`${x.fromAccount}|${x.toAccount}|${x.amount}|${x.remarks || ""}`, String(x._id));
    });

    group.forEach((e) => {
      const key = `${e.fromAccount}|${e.toAccount}|${e.amount}|${e.remarks}`;
      if (seen.has(key)) dupes.push({ rowNum: e.rowNum, id: seen.get(key), amount: e.amount });
    });
  }

  if (dupes.length) {
    console.log(`\nWARNING - ${dupes.length} row(s) appear to be already imported:`);
    dupes.slice(0, 20).forEach((d) =>
      console.log(`  row ${d.rowNum}  ${inr(d.amount)}  -> existing ${d.id}`)
    );
    if (dupes.length > 20) console.log(`  ...and ${dupes.length - 20} more`);
    console.log("");
    if (APPLY && !ALLOW_DUPES) {
      console.error("Refusing to import. Re-run with --allow-duplicates if these are genuinely separate transfers.");
      await mongoose.disconnect();
      process.exit(1);
    }
  } else {
    console.log("No duplicates found.\n");
  }

  // --- build documents ---
  const docs = ENTRIES.map((e) => ({
    fromAccount: e.fromAccount,
    toAccount: e.toAccount,
    amount: e.amount,
    date: new Date(e.date),
    branch: e.branch || null,
    reference: e.reference || "",
    remarks: e.remarks || "",
    receipts: [],
    isCancelled: false,
    createdBy: {
      name: "Bulk Import",
      email: "import@system",
      branch: e.branch || "",
      date: new Date(),
    },
    log: [
      {
        action: "Created",
        note: "Imported from contra-entries_active_2026-08-12.xlsx",
        performedBy: { name: "Bulk Import", email: "import@system" },
        performedAt: new Date(),
      },
    ],
  }));

  // --- per-pair and per-day summaries ---
  const byPair = {}, byDay = {};
  docs.forEach((d, i) => {
    const pair = `${d.fromAccount} -> ${d.toAccount}`;
    byPair[pair] = (byPair[pair] || 0) + d.amount;
    byDay[ENTRIES[i].date] = (byDay[ENTRIES[i].date] || 0) + d.amount;
  });

  console.log("--- BY TRANSFER PAIR ---");
  Object.entries(byPair).sort((a, b) => b[1] - a[1])
    .forEach(([p, v]) => console.log(`  ${p.padEnd(34)} ${inr(v)}`));

  console.log(`\n--- BY DAY --- (${Object.keys(byDay).length} days)`);
  Object.entries(byDay).sort()
    .forEach(([d, v]) => console.log(`  ${d}   ${inr(v)}`));

  if (!APPLY) {
    console.log(`\nDRY RUN - nothing written. Re-run with --apply to import.`);
    console.log(`Reconcile the net effect above against your bank statements before applying.`);
    await mongoose.disconnect();
    return;
  }

  const inserted = await AccountTransfer.insertMany(docs, { ordered: true });
  console.log(`\nInserted ${inserted.length} contra entries moving ${inr(total)}.`);

  const reportPath = `contra-import-report-${Date.now()}.json`;
  fs.writeFileSync(reportPath, JSON.stringify({
    source: "contra-entries_active_2026-08-12.xlsx",
    rowCount: inserted.length,
    totalMoved: total,
    netEffectByAccount: net,
    insertedIds: inserted.map((d) => String(d._id)),
  }, null, 2));
  console.log(`Report and inserted IDs written to ${reportPath} - keep this, it is your undo list.`);

  await mongoose.disconnect();
  console.log("Done.");
}

run().catch(async (err) => {
  console.error("\nFATAL:", err);
  await mongoose.disconnect().catch(() => {});
  process.exit(1);
});