import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import mongoose from "mongoose";
import connectDB from "@/lib/db";
import Transactions from "@/models/Transactions";
import Patient from "@/models/Patient";
import { checkPeriodLock } from "@/lib/periodLock";
import { checkCascadeOnDelete } from "@/lib/cascadeIntegrity";
import { withDbTransaction } from "@/lib/externalPartyDerivation";

// Creates a REVERSAL: a negative-amount transaction pointing at the row it reverses.
//
// Why negative rather than a flag — see the reversalOf comment in src/models/Transactions.js.
// The short version: a negative row nets out correctly in every existing aggregation without
// editing any of them, which is the only approach that cannot leave a stale sum somewhere.
//
// This is the ONLY writer of negative amounts. The normal entry forms never expose them.

const ALLOWED_ROLES = ["admin", "super-admin"];

// Copied onto the reversal so it lands in exactly the same buckets as the original — same
// account, same branch, same category. furtherMode especially: the money must come back out of
// the account it went into, or the totals net to zero while the per-account balances do not.
const MIRRORED_FIELDS = [
  "patient",
  "patientName",
  "patientPhone",
  "procedure",
  "transactionCategory",
  "costType",
  "branch",
  "method",
  "furtherMode",
  "receiptMode",
  "expense",
  "expenseType",
  "payableId",
  "receivableId",
];

export async function POST(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    if (!ALLOWED_ROLES.includes(session.user.role)) {
      return NextResponse.json({ error: "Forbidden — admin access required" }, { status: 403 });
    }

    await connectDB();

    const { id } = await params;
    const body = await request.json();
    const { reason, remarks, date } = body;

    if (!reason || !String(reason).trim()) {
      return NextResponse.json({ error: "A reason is required to reverse a transaction" }, { status: 400 });
    }

    const original = await Transactions.findById(id);
    if (!original) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
    }

    // ── Guard: never reverse a reversal ────────────────────────────────────────────────
    if (original.reversalOf) {
      return NextResponse.json(
        {
          error:
            "This row is itself a reversal. Reverse the ORIGINAL transaction instead — a chain of reversals is impossible to read in an audit.",
        },
        { status: 400 },
      );
    }

    if ((original.amount || 0) <= 0) {
      return NextResponse.json(
        { error: "Only a positive-amount transaction can be reversed." },
        { status: 400 },
      );
    }

    // ── Guard: no double reversal ──────────────────────────────────────────────────────
    // Amounts are stored negative, so their absolute sum is what has already been returned.
    const [alreadyAgg] = await Transactions.aggregate([
      { $match: { reversalOf: original._id } },
      { $group: { _id: null, total: { $sum: "$amount" }, n: { $sum: 1 } } },
    ]);
    const alreadyReversed = Math.abs(alreadyAgg?.total || 0);
    const remaining = Math.round(((original.amount || 0) - alreadyReversed) * 100) / 100;

    if (remaining <= 0) {
      return NextResponse.json(
        {
          error: `This transaction is already fully reversed (₹${alreadyReversed.toLocaleString("en-IN")} of ₹${(original.amount || 0).toLocaleString("en-IN")}).`,
          alreadyReversed,
        },
        { status: 400 },
      );
    }

    // Defaults to the full remaining balance — the common case is a complete reversal.
    const requested = body.amount === undefined || body.amount === null ? remaining : Number(body.amount);
    if (!Number.isFinite(requested) || requested <= 0) {
      return NextResponse.json({ error: "Reversal amount must be greater than zero" }, { status: 400 });
    }
    if (requested > remaining) {
      return NextResponse.json(
        {
          error:
            `Reversing ₹${requested.toLocaleString("en-IN")} would take the total past the original. ` +
            `₹${alreadyReversed.toLocaleString("en-IN")} of ₹${(original.amount || 0).toLocaleString("en-IN")} has already been reversed; ` +
            `₹${remaining.toLocaleString("en-IN")} remains.`,
          alreadyReversed,
          remaining,
        },
        { status: 400 },
      );
    }

    // ── Guard: closed periods ──────────────────────────────────────────────────────────
    // A closed period stays closed and the correction lands in the open one, so the reversal is
    // dated TODAY rather than back-dated to the original. Only the reversal's own date is
    // checked — the original is not being edited, so its period is not being disturbed.
    const originalLocked = await checkPeriodLock(original);
    const reversalDate = originalLocked ? new Date() : date ? new Date(date) : new Date(original.date);

    const reversalLock = await checkPeriodLock({
      furtherMode: original.furtherMode,
      date: reversalDate,
    });
    if (reversalLock) {
      return NextResponse.json(
        {
          error: `The reversal cannot be dated ${reversalDate.toLocaleDateString("en-IN")}: ${reversalLock}`,
          periodLocked: true,
        },
        { status: 423 },
      );
    }

    // ── Guard: cascade ─────────────────────────────────────────────────────────────────
    // A FULL reversal leaves the original recognising nothing, so any payable/receivable it
    // created is in the same position it would be after a delete. Reuses the delete-side check
    // rather than restating the rule, so a reversal cannot orphan what a delete would refuse to.
    const isFullReversal = Math.abs(requested - remaining) < 0.01;
    let cascade = null;
    if (isFullReversal) {
      cascade = await checkCascadeOnDelete(original);
      if (cascade.blocked) {
        return NextResponse.json(
          {
            error: "This transaction cannot be fully reversed yet.",
            reasons: cascade.reasons,
            // Partial is still available — it does not fully unwind the linked document.
            hint: `A partial reversal below ₹${remaining.toLocaleString("en-IN")} is still possible.`,
          },
          { status: 409 },
        );
      }
    }

    const actor = {
      name: session.user.name,
      email: session.user.email,
      branch: session.user.branch,
    };

    // Self-explanatory in a bank reconciliation months later: what, who, and which original.
    const narration = [
      `REVERSAL — ${String(reason).trim()}`,
      original.patientName || undefined,
      original.paymentId ? `ref ${original.paymentId}` : undefined,
      `against ${original._id}`,
      remarks ? String(remarks).trim() : undefined,
    ]
      .filter(Boolean)
      .join(" · ");

    const result = await withDbTransaction(async (dbSession) => {
      const doc = {};
      for (const f of MIRRORED_FIELDS) {
        if (original[f] !== undefined && original[f] !== null) doc[f] = original[f];
      }

      const [reversal] = await Transactions.create(
        [
          {
            ...doc,
            amount: -Math.abs(requested),
            // Never inherited: a reversal of a settlement is itself a settlement only in the
            // same sense the original was, and isSettlement already governs that via the
            // mirrored payableId/receivableId. Copying the original's flag keeps the pair
            // symmetric so they net to zero in whichever totals counted the original.
            isSettlement: original.isSettlement === true,
            reversalOf: original._id,
            reversalReason: String(reason).trim(),
            date: reversalDate,
            remarks: narration,
            paymentId: original.paymentId || "",
            approvalStatus: "APPROVED",
            createdBy: { ...actor, date: new Date() },
          },
        ],
        { session: dbSession },
      );

      // Only a FULL reversal closes the original. A partial one leaves it open so the rest can
      // still be reversed later.
      const nowReversed = alreadyReversed + Math.abs(requested);
      const fullyReversed = nowReversed >= (original.amount || 0) - 0.01;
      if (fullyReversed) {
        original.isReversed = true;
        original.editors = original.editors || [];
        original.editors.push({
          ...actor,
          date: new Date(),
          updatedFields: [{ name: "isReversed", previousValue: "false", newValue: "true" }],
        });
        await original.save({ session: dbSession });
      }

      // Patient money. Mirrors what transplant/create does on the way in, with the sign
      // flipped — the patient's received figure must agree with the sum of their transactions.
      // The Patient pre-save hook re-derives ops.status from the new amountReceived, which is
      // intended: a reversed payment means the patient did not, in fact, pay.
      let patientStatus = null;
      if (original.patient && original.costType === "Revenue") {
        const patient = await Patient.findById(original.patient).session(dbSession);
        if (patient) {
          patient.payments = patient.payments || {};
          const before = patient.ops?.status;
          patient.payments.amountReceived =
            Math.round(((patient.payments.amountReceived || 0) - Math.abs(requested)) * 100) / 100;
          if (patient.payments.amountReceived < 0) patient.payments.amountReceived = 0;
          patient.payments.transactions = patient.payments.transactions || [];
          patient.payments.transactions.push(reversal._id);

          // The hook only re-derives pendingAmount when counselling.finlpackage is set. Without
          // it a stale pendingAmount <= 0 would leave the patient on SURGERY_BOOKED even though
          // the money is gone — 22 patients in this database are in that position. Recompute it
          // here so the status the hook derives is based on a current figure.
          if (!patient.counselling?.finlpackage) {
            const total = patient.payments.totalAmount || 0;
            patient.payments.pendingAmount = Math.max(
              0,
              total - patient.payments.amountReceived - (patient.payments.discount || 0),
            );
          }

          await patient.save({ session: dbSession });
          patientStatus = { before, after: patient.ops?.status, amountReceived: patient.payments.amountReceived };
        }
      }

      return { reversal, fullyReversed, patientStatus };
    });

    return NextResponse.json(
      {
        success: true,
        message: result.fullyReversed
          ? "Transaction fully reversed"
          : "Partial reversal recorded — the original remains open for further reversal",
        reversal: result.reversal,
        original: { _id: original._id, amount: original.amount, isReversed: result.fullyReversed },
        alreadyReversed: alreadyReversed + Math.abs(requested),
        remaining: Math.round((remaining - Math.abs(requested)) * 100) / 100,
        patientStatus: result.patientStatus,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error("Error reversing transaction:", error);
    return NextResponse.json({ error: error.message || "Failed to reverse transaction" }, { status: 500 });
  }
}

// Read-only companion to the POST above: what has already been reversed against this row.
// The dialog needs it to show the remaining balance and default its amount correctly — without
// it a partial reversal is invisible until the server rejects the second one.
export async function GET(request, { params }) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }
    if (!ALLOWED_ROLES.includes(session.user.role)) {
      return NextResponse.json({ error: "Forbidden — admin access required" }, { status: 403 });
    }

    await connectDB();
    const { id } = await params;

    const original = await Transactions.findById(id).lean();
    if (!original) {
      return NextResponse.json({ error: "Transaction not found" }, { status: 404 });
    }

    const reversals = await Transactions.find({ reversalOf: original._id })
      .select("_id amount date reversalReason remarks createdBy")
      .sort({ date: 1 })
      .lean();

    const alreadyReversed = Math.abs(reversals.reduce((s, r) => s + (r.amount || 0), 0));
    const remaining = Math.round(((original.amount || 0) - alreadyReversed) * 100) / 100;

    // Why the action is unavailable, in the same words the POST would use, so the dialog can
    // explain itself rather than presenting a form that is guaranteed to fail.
    let blockedReason = null;
    if (original.reversalOf) blockedReason = "This row is itself a reversal. Reverse the original instead.";
    else if ((original.amount || 0) <= 0) blockedReason = "Only a positive-amount transaction can be reversed.";
    else if (remaining <= 0) blockedReason = "This transaction is already fully reversed.";

    const periodLock = await checkPeriodLock(original);

    return NextResponse.json({
      success: true,
      originalAmount: original.amount || 0,
      alreadyReversed,
      remaining,
      isReversed: original.isReversed === true,
      reversals,
      blockedReason,
      // When the original sits in a closed period the reversal must be dated today — the dialog
      // says so up front rather than letting the user pick a date the POST will refuse.
      originalPeriodLocked: !!periodLock,
      periodLockReason: periodLock || null,
    });
  } catch (error) {
    console.error("Error reading reversal state:", error);
    return NextResponse.json({ error: "Failed to read reversal state" }, { status: 500 });
  }
}
