import { NextResponse } from "next/server";
import { DBConnection } from "@/lib/db";
import Leads from "@/models/leads";
import Blog from "@/models/blog";
import User from "@/models/user";

export async function POST(req) {
  try {
    const { question, history = [] } = await req.json();

    if (!question?.trim()) {
      return NextResponse.json({ answer: "Please ask something." });
    }

    await DBConnection();

    // ── Time windows ──────────────────────────────────────────────
    const now = new Date();
    const todayStart = new Date(now); todayStart.setHours(0, 0, 0, 0);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const weekStart  = new Date(now); weekStart.setDate(now.getDate() - 7);

    // ── Parallel DB fetch ─────────────────────────────────────────
    const [
      totalLeads,
      todayLeads,
      weekLeads,
      monthLeads,
      recentLeads,
      leadsByService,
      totalBlogs,
      recentBlogs,
      totalUsers,
    ] = await Promise.all([
      Leads.countDocuments(),
      Leads.countDocuments({ createdAt: { $gte: todayStart } }),
      Leads.countDocuments({ createdAt: { $gte: weekStart } }),
      Leads.countDocuments({ createdAt: { $gte: monthStart } }),
      Leads.find().sort({ createdAt: -1 }).limit(15).lean(),
      Leads.aggregate([
        { $group: { _id: "$serviceType", count: { $sum: 1 } } },
        { $sort: { count: -1 } },
      ]),
      Blog.countDocuments(),
      Blog.find().sort({ createdAt: -1 }).limit(5).select("blogTitle createdAt pageUrl").lean(),
      User.countDocuments(),
    ]);

    // ── Build CRM context for Claude ──────────────────────────────
    const crmContext = {
      timestamp: now.toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
      leads: {
        total: totalLeads,
        today: todayLeads,
        thisWeek: weekLeads,
        thisMonth: monthLeads,
        byService: leadsByService.map((s) => ({
          service: s._id || "Not specified",
          count: s.count,
        })),
        recent15: recentLeads.map((l) => ({
          name: l.name,
          phone: l.phone,
          email: l.email || "—",
          service: l.serviceType || "Not specified",
          message: l.message || "—",
          date: new Date(l.createdAt).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
        })),
      },
      blogs: {
        total: totalBlogs,
        recent: recentBlogs.map((b) => ({
          title: b.blogTitle,
          url: b.pageUrl,
          date: new Date(b.createdAt).toLocaleString("en-IN"),
        })),
      },
      adminUsers: totalUsers,
    };

    // ── Keep last 6 messages for context (3 exchanges) ────────────
    const trimmedHistory = history.slice(-6);

    const messages = [
      ...trimmedHistory,
      {
        role: "user",
        content: `Live CRM Data:\n${JSON.stringify(crmContext, null, 2)}\n\nQuestion: ${question}`,
      },
    ];

    // ── Call OpenAI ───────────────────────────────────────────────
    const openaiRes = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o",
        max_tokens: 1000,
        messages: [
          {
            role: "system",
            content: `You are Saniya — the intelligent AI assistant for Ryan Clinic, a premium hair transplant clinic with branches in Delhi, Mumbai, and Hyderabad. The clinic specializes in the Turkey Sapphire FUE technique.

You have real-time access to the clinic's CRM database. Your job is to answer the superadmin's questions about leads, blog posts, performance, and clinic data.

Rules:
- Be concise, professional, and friendly — like a sharp employee who knows the business inside out
- When listing leads, format them clearly (Name | Phone | Service | Date)
- For counts and stats, give direct answers with context (e.g. "12 leads today, up from yesterday's 8")
- If asked about something not in the data (e.g. transactions, patients from the main CRM), politely say that data lives in the Ryan MediHub CRM at ryanmedihub.com
- Always respond in the same language the admin uses (Hindi or English)
- Current time is IST (India Standard Time)`,
          },
          ...messages,
        ],
      }),
    });

    const openaiData = await openaiRes.json();

    if (!openaiRes.ok) {
      console.error("OpenAI API error:", openaiData);
      return NextResponse.json({ answer: "OpenAI API error. Check your OPENAI_API_KEY." }, { status: 500 });
    }

    const answer = openaiData.choices?.[0]?.message?.content || "Sorry, I could not process that.";
    return NextResponse.json({ answer });

  } catch (err) {
    console.error("Saniya route error:", err);
    return NextResponse.json({ answer: "Internal error. Please try again." }, { status: 500 });
  }
}