"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { Mic, MicOff, Send, Sparkles, Volume2, VolumeX, Trash2 } from "lucide-react";

// ── Helpers ───────────────────────────────────────────────────────────
function formatTime(date) {
  return new Date(date).toLocaleTimeString("en-IN", {
    hour: "2-digit", minute: "2-digit",
  });
}

const WAKE_PHRASE = "hi saniya";
const WAKE_PHRASES = ["hi saniya", "hii saniya", "hey saniya", "hello saniya"];

// ── Component ─────────────────────────────────────────────────────────
export default function SaniyaPage() {
  const [messages, setMessages]         = useState([]);
  const [input, setInput]               = useState("");
  const [loading, setLoading]           = useState(false);
  const [listening, setListening]       = useState(false);   // active capture
  const [wakeMode, setWakeMode]         = useState(false);   // background wake-word
  const [ttsEnabled, setTtsEnabled]     = useState(true);
  const [transcript, setTranscript]     = useState("");
  const [statusMsg, setStatusMsg]       = useState("Say \"Hii Saniya\" or type below");

  const chatEndRef   = useRef(null);
  const recognRef    = useRef(null);   // SpeechRecognition instance
  const wakeRef      = useRef(null);   // background wake-word recogniser
  const historyRef   = useRef([]);     // Claude message history

  // Keep history in sync
  useEffect(() => {
    historyRef.current = messages
      .filter((m) => m.role !== "system")
      .slice(-6)
      .map((m) => ({ role: m.role, content: m.content }));
  }, [messages]);

  // Scroll to bottom on new message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, transcript]);

  // ── Greet on mount ──────────────────────────────────────────────
  useEffect(() => {
    const greeting = {
      id: Date.now(),
      role: "assistant",
      content: "Hii! Main Saniya hoon — Ryan Clinic ki AI assistant. Clinic ke baare mein kuch bhi puchh sakte ho — leads, blogs, ya koi bhi data. Bolo kya jaanna hai? 😊",
      time: new Date(),
    };
    setMessages([greeting]);
    if (ttsEnabled) speak(greeting.content);
  }, []); // eslint-disable-line

  // ── TTS ─────────────────────────────────────────────────────────
  const speak = useCallback((text) => {
    if (!window.speechSynthesis || !ttsEnabled) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.lang  = "hi-IN";
    utter.rate  = 1.0;
    utter.pitch = 1.1;
    // prefer a female voice
    const voices = window.speechSynthesis.getVoices();
    const female = voices.find(
      (v) => v.lang.startsWith("hi") || v.name.toLowerCase().includes("female")
    );
    if (female) utter.voice = female;
    window.speechSynthesis.speak(utter);
  }, [ttsEnabled]);

  // ── Send to Claude ───────────────────────────────────────────────
  const sendMessage = useCallback(async (text) => {
    const question = text?.trim() || input.trim();
    if (!question || loading) return;

    setInput("");
    setTranscript("");
    setLoading(true);
    setStatusMsg("Saniya is thinking...");

    const userMsg = { id: Date.now(), role: "user", content: question, time: new Date() };
    setMessages((prev) => [...prev, userMsg]);

    try {
      const res  = await fetch("/api/saniya", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question, history: historyRef.current }),
      });
      const data = await res.json();
      const answer = data.answer || "Kuch samajh nahi aaya, dobara puchho.";

      const aiMsg = { id: Date.now() + 1, role: "assistant", content: answer, time: new Date() };
      setMessages((prev) => [...prev, aiMsg]);

      if (ttsEnabled) speak(answer);
    } catch {
      const errMsg = { id: Date.now() + 1, role: "assistant", content: "Network error. Please try again.", time: new Date() };
      setMessages((prev) => [...prev, errMsg]);
    } finally {
      setLoading(false);
      setStatusMsg("Say \"Hii Saniya\" or type below");
    }
  }, [input, loading, ttsEnabled, speak]);

  // ── Active voice capture ─────────────────────────────────────────
  const startListening = useCallback(() => {
    if (!window.SpeechRecognition && !window.webkitSpeechRecognition) {
      alert("Voice not supported in this browser. Use Chrome.");
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recog = new SR();
    recog.lang            = "hi-IN";
    recog.continuous      = false;
    recog.interimResults  = true;

    recog.onstart  = () => { setListening(true); setStatusMsg("Sun rahi hoon... bolo"); };
    recog.onresult = (e) => {
      const t = Array.from(e.results).map((r) => r[0].transcript).join("");
      setTranscript(t);
    };
    recog.onend = () => {
      setListening(false);
      setStatusMsg("Say \"Hii Saniya\" or type below");
      const final = recognRef._lastTranscript;
      if (final?.trim()) sendMessage(final.trim());
    };
    recog.onerror = () => { setListening(false); setStatusMsg("Voice error. Try again."); };

    // store final transcript when result fires
    recog.addEventListener("result", (e) => {
      const isFinal = e.results[e.results.length - 1].isFinal;
      if (isFinal) {
        recognRef._lastTranscript = Array.from(e.results).map((r) => r[0].transcript).join("");
      }
    });

    recognRef.current = recog;
    recog.start();
  }, [sendMessage]);

  const stopListening = useCallback(() => {
    recognRef.current?.stop();
    setListening(false);
  }, []);

  // ── Wake-word background listener ────────────────────────────────
  const startWakeMode = useCallback(() => {
    if (!window.SpeechRecognition && !window.webkitSpeechRecognition) return;
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const wake = new SR();
    wake.lang           = "hi-IN";
    wake.continuous     = true;
    wake.interimResults = true;

    wake.onresult = (e) => {
      const t = Array.from(e.results).map((r) => r[0].transcript).join("").toLowerCase().trim();
      const triggered = WAKE_PHRASES.some((p) => t.includes(p));
      if (triggered) {
        wake.stop();
        setWakeMode(false);
        setStatusMsg("Wake word detected! Bolo...");
        setTimeout(() => startListening(), 400);
      }
    };
    wake.onend = () => {
      // auto-restart wake mode if still in wake mode
      if (wakeRef._active) {
        try { wake.start(); } catch {}
      }
    };

    wakeRef._active = true;
    wakeRef.current = wake;
    try { wake.start(); setWakeMode(true); setStatusMsg("Listening for \"Hii Saniya\"..."); }
    catch (e) { console.error(e); }
  }, [startListening]);

  const stopWakeMode = useCallback(() => {
    wakeRef._active = false;
    wakeRef.current?.stop();
    setWakeMode(false);
    setStatusMsg("Say \"Hii Saniya\" or type below");
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      wakeRef._active = false;
      wakeRef.current?.stop();
      recognRef.current?.stop();
      window.speechSynthesis?.cancel();
    };
  }, []);

  // ── Render ────────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-[#fff5ec] flex flex-col">

      {/* ── Header ── */}
      <div className="bg-[#D32F2F] text-white px-6 py-4 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-wide">Saniya</h1>
            <p className="text-xs text-red-100">Ryan Clinic AI Assistant</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {/* TTS toggle */}
          <button
            onClick={() => { setTtsEnabled(!ttsEnabled); window.speechSynthesis?.cancel(); }}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition"
            title="Toggle voice output"
          >
            {ttsEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
          {/* Clear chat */}
          <button
            onClick={() => { setMessages([]); historyRef.current = []; }}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition"
            title="Clear chat"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ── Status bar ── */}
      <div className={`text-center py-2 text-xs font-medium transition-all ${
        listening  ? "bg-green-100 text-green-700" :
        wakeMode   ? "bg-amber-50 text-amber-600" :
        loading    ? "bg-blue-50 text-blue-600" :
                     "bg-white text-gray-400"
      }`}>
        {listening && <span className="inline-block w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse" />}
        {wakeMode  && <span className="inline-block w-2 h-2 rounded-full bg-amber-400 mr-2 animate-pulse" />}
        {loading   && <span className="inline-block w-2 h-2 rounded-full bg-blue-500 mr-2 animate-pulse" />}
        {statusMsg}
      </div>

      {/* ── Chat messages ── */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 max-w-3xl w-full mx-auto">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {msg.role === "assistant" && (
              <div className="w-8 h-8 rounded-full bg-[#D32F2F] flex items-center justify-center mr-2 flex-shrink-0 mt-1">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
            )}
            <div className={`max-w-[78%] ${msg.role === "user" ? "items-end" : "items-start"} flex flex-col`}>
              <div className={`px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap ${
                msg.role === "user"
                  ? "bg-[#D32F2F] text-white rounded-tr-sm"
                  : "bg-white text-gray-800 shadow-sm rounded-tl-sm border border-red-50"
              }`}>
                {msg.content}
              </div>
              <span className="text-xs text-gray-400 mt-1 px-1">{formatTime(msg.time)}</span>
            </div>
          </div>
        ))}

        {/* Interim transcript bubble */}
        {transcript && (
          <div className="flex justify-end">
            <div className="bg-red-100 text-red-700 px-4 py-2 rounded-2xl rounded-tr-sm text-sm italic max-w-[78%]">
              {transcript}
            </div>
          </div>
        )}

        {/* Loading dots */}
        {loading && (
          <div className="flex justify-start">
            <div className="w-8 h-8 rounded-full bg-[#D32F2F] flex items-center justify-center mr-2 flex-shrink-0">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div className="bg-white px-4 py-3 rounded-2xl rounded-tl-sm shadow-sm border border-red-50">
              <div className="flex gap-1 items-center h-4">
                <span className="w-2 h-2 bg-[#D32F2F] rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 bg-[#D32F2F] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 bg-[#D32F2F] rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* ── Input bar ── */}
      <div className="bg-white border-t border-red-100 px-4 py-3 max-w-3xl w-full mx-auto">

        {/* Wake word btn */}
        <div className="flex justify-center mb-3">
          <button
            onClick={wakeMode ? stopWakeMode : startWakeMode}
            className={`flex items-center gap-2 px-5 py-2 rounded-full text-sm font-medium transition-all ${
              wakeMode
                ? "bg-amber-100 text-amber-700 border border-amber-300"
                : "bg-red-50 text-[#D32F2F] border border-red-200 hover:bg-red-100"
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${wakeMode ? "bg-amber-500 animate-pulse" : "bg-gray-300"}`} />
            {wakeMode ? 'Listening for "Hii Saniya"...' : 'Enable Wake Word'}
          </button>
        </div>

        {/* Text + mic row */}
        <div className="flex gap-2 items-end">
          <textarea
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder="Kuch bhi puchho... (e.g. aaj kitne leads aaye?)"
            className="flex-1 resize-none border border-gray-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-[#D32F2F] bg-gray-50"
          />

          {/* Mic button */}
          <button
            onMouseDown={startListening}
            onMouseUp={stopListening}
            onTouchStart={startListening}
            onTouchEnd={stopListening}
            disabled={loading}
            className={`p-3 rounded-xl transition-all flex-shrink-0 ${
              listening
                ? "bg-green-500 text-white scale-110 shadow-lg"
                : "bg-red-50 text-[#D32F2F] border border-red-200 hover:bg-[#D32F2F] hover:text-white"
            }`}
            title="Hold to speak"
          >
            {listening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Send button */}
          <button
            onClick={() => sendMessage()}
            disabled={!input.trim() || loading}
            className="p-3 rounded-xl bg-[#D32F2F] text-white disabled:opacity-40 hover:bg-red-700 transition flex-shrink-0"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>

        <p className="text-center text-xs text-gray-400 mt-2">
          Hold mic to speak • Press Enter to send • Say "Hii Saniya" to activate
        </p>
      </div>
    </div>
  );
}