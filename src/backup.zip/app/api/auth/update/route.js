// app/api/users/update-password/route.js

import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import User from '@/models/User';

export async function PUT(request) {
  try {
    const { userId, email, currentPassword, newPassword } = await request.json();

    // Validation
    if (!newPassword) {
      return NextResponse.json(
        { error: 'New password is required' },
        { status: 400 }
      );
    }

    if (newPassword.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters long' },
        { status: 400 }
      );
    }

    // Connect to database if not already connected
    if (mongoose.connection.readyState !== 1) {
      await mongoose.connect(process.env.MONGODB_URI);
    }

    // Find user by ID or email - explicitly select password field
    let user;
    if (userId) {
      user = await User.findById(userId).select('+password');
    } else {
      user = await User.findOne({ email }).select('+password');
    }

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    // If currentPassword is provided, verify it
    if (currentPassword) {
      const isPasswordValid = await user.correctPassword(currentPassword, user.password);
      if (!isPasswordValid) {
        return NextResponse.json(
          { error: 'Current password is incorrect' },
          { status: 401 }
        );
      }
    }

    // Update password - pre-save hook will hash it automatically
    user.password = newPassword;
    await user.save();

    return NextResponse.json(
      { 
        success: true,
        message: 'Password updated successfully',
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      },
      { status: 200 }
    );

  } catch (error) {
    console.error('Password update error:', error);
    return NextResponse.json(
      { error: 'Internal server error', details: error.message },
      { status: 500 }
    );
  }
}