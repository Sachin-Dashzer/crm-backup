"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  DollarSign,
  Save,
  Search,
  X,
  User,
  Phone,
  Calendar,
  FileText,
  Printer,
  Download,
} from "lucide-react";
import ReceptionSidebar from "@/components/ReceptionSidebar";
import { useToast } from "@/components/Toast";
import html2pdf from "html2pdf.js";

export default function CreateBill() {
  const router = useRouter();
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showPrintPreview, setShowPrintPreview] = useState(false);
  const [createdTransaction, setCreatedTransaction] = useState(null);
  const billRef = useRef();

  const [billData, setBillData] = useState({
    costType: "Revenue",
    method: "cash",
    procedure: "hair transplant",
    paymentType: "Booking",
    amount: "",
    date: new Date().toISOString().split("T")[0],
    remarks: "",
    branch: "",
  });

  useEffect(() => {
    // Get user's branch from cookie
    const userBranch = document.cookie
      .split("; ")
      .find((row) => row.startsWith("userBranch="))
      ?.split("=")[1];

    if (userBranch) {
      setBillData((prev) => ({ ...prev, branch: userBranch }));
    }
  }, []);

  const handleSearchPatient = async () => {
    if (!searchQuery.trim()) {
      toast.warning("Please enter a search term");
      return;
    }

    try {
      const res = await fetch(
        `/api/patients/get-id?search=${encodeURIComponent(searchQuery)}`
      );

      if (!res.ok) throw new Error("Search failed");

      const data = await res.json();
      setSearchResults(data.patients || []);

      if (data.patients?.length === 0) {
        toast.info("No patients found");
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to search patients");
    }
  };

  const handleSelectPatient = (patient) => {
    setSelectedPatient(patient);
    setSearchResults([]);
    setSearchQuery("");
    setBillData((prev) => ({
      ...prev,
      branch: patient.personal?.branch || prev.branch,
    }));
  };

  const handleChange = (field, value) => {
    setBillData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!selectedPatient) {
      toast.error("Please select a patient");
      return;
    }

    if (!billData.amount || billData.amount <= 0) {
      toast.error("Please enter a valid amount");
      return;
    }

    setLoading(true);
    try {
      const payload = {
        ...billData,
        patient: selectedPatient._id,
        amount: Number(billData.amount),
      };

      const res = await fetch("/api/transactions/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (res.ok) {
        toast.success("Bill created successfully!");
        setCreatedTransaction(data.data);
        setShowPrintPreview(true);
      } else {
        toast.error(data.error || "Failed to create bill");
      }
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to create bill");
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setSelectedPatient(null);
    setSearchQuery("");
    setSearchResults([]);
    setShowPrintPreview(false);
    setCreatedTransaction(null);
    const userBranch = billData.branch;
    setBillData({
      costType: "Revenue",
      method: "cash",
      procedure: "hair transplant",
      paymentType: "Booking",
      amount: "",
      date: new Date().toISOString().split("T")[0],
      remarks: "",
      branch: userBranch,
    });
  };

  const generatePDF = () => {
    if (!billRef.current) {
      toast.error("Bill preview not available");
      return;
    }

    const element = billRef.current;
    const opt = {
      margin: [10, 10, 10, 10],
      filename: `bill-${createdTransaction?._id?.slice(-8) || 'receipt'}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { 
        scale: 2,
        useCORS: true,
        logging: false,
        letterRendering: true
      },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };

    html2pdf()
      .set(opt)
      .from(element)
      .save()
      .then(() => {
        toast.success("PDF downloaded successfully!");
      })
      .catch((error) => {
        console.error("Error generating PDF:", error);
        toast.error("Failed to generate PDF");
      });
  };

  const printBill = () => {
    if (!billRef.current) {
      toast.error("Bill preview not available");
      return;
    }

    const printContent = billRef.current.innerHTML;

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error("Please allow pop-ups to print");
      return;
    }

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Print Bill</title>
          <style>
            body { 
              font-family: 'Arial', sans-serif; 
              margin: 20px;
              color: #000;
              line-height: 1.4;
            }
            .bill-container { 
              max-width: 800px; 
              margin: 0 auto; 
              border: 2px solid #000; 
              padding: 25px; 
            }
            .header { 
              text-align: center; 
              border-bottom: 2px solid #000; 
              padding-bottom: 20px; 
              margin-bottom: 25px; 
            }
            .clinic-name { 
              font-size: 28px; 
              font-weight: bold; 
              margin-bottom: 8px; 
              color: #000;
            }
            .clinic-address {
              font-size: 14px;
              margin-bottom: 5px;
            }
            .bill-title {
              font-size: 24px;
              font-weight: bold;
              margin: 20px 0;
              text-align: center;
            }
            .bill-details { 
              margin: 25px 0; 
            }
            .detail-section {
              margin-bottom: 20px;
            }
            .detail-section h3 {
              border-bottom: 1px solid #000;
              padding-bottom: 8px;
              margin-bottom: 12px;
              font-size: 16px;
            }
            .detail-row { 
              display: flex; 
              justify-content: space-between; 
              margin-bottom: 8px; 
              padding: 6px 0; 
            }
            .detail-row:nth-child(even) { 
              background: #f8f9fa; 
            }
            .total-row { 
              border-top: 2px solid #000; 
              font-weight: bold; 
              font-size: 18px; 
              padding-top: 12px;
              margin-top: 20px;
            }
            .signature-section {
              margin-top: 40px;
              display: flex;
              justify-content: space-between;
            }
            .signature {
              text-align: center;
              width: 200px;
            }
            .signature-line {
              border-top: 1px solid #000;
              margin-top: 60px;
              padding-top: 8px;
            }
            .footer { 
              text-align: center; 
              margin-top: 30px; 
              border-top: 1px solid #000; 
              padding-top: 15px; 
              font-size: 12px; 
            }
            @media print {
              body { margin: 0; }
              .bill-container { 
                border: none; 
                padding: 15px;
                box-shadow: none;
              }
              .no-print { display: none !important; }
            }
          </style>
        </head>
        <body>
          <div class="bill-container">
            ${printContent}
          </div>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(() => {
                window.close();
              }, 100);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric",
    });
  };

  // Fixed convertToWords function - non-recursive for numbers < 100
  const convertToWords = (amount) => {
    if (!amount || amount === 0) return 'Zero Rupees Only';
    
    const num = parseInt(amount);
    if (isNaN(num)) return '';
    
    const ones = [
      '', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 
      'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 
      'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'
    ];
    
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    
    const convertLessThanHundred = (n) => {
      if (n === 0) return '';
      if (n < 20) return ones[n];
      const tenDigit = Math.floor(n / 10);
      const oneDigit = n % 10;
      return tens[tenDigit] + (oneDigit > 0 ? ' ' + ones[oneDigit] : '');
    };
    
    const convertLessThanThousand = (n) => {
      if (n === 0) return '';
      if (n < 100) return convertLessThanHundred(n);
      
      const hundredDigit = Math.floor(n / 100);
      const remainder = n % 100;
      
      let result = ones[hundredDigit] + ' Hundred';
      if (remainder > 0) {
        result += ' and ' + convertLessThanHundred(remainder);
      }
      return result;
    };
    
    let words = '';
    let remaining = num;
    
    // Crores (10,000,000)
    if (remaining >= 10000000) {
      const crores = Math.floor(remaining / 10000000);
      words += convertLessThanThousand(crores) + ' Crore ';
      remaining %= 10000000;
    }
    
    // Lakhs (100,000)
    if (remaining >= 100000) {
      const lakhs = Math.floor(remaining / 100000);
      words += convertLessThanThousand(lakhs) + ' Lakh ';
      remaining %= 100000;
    }
    
    // Thousands (1,000)
    if (remaining >= 1000) {
      const thousands = Math.floor(remaining / 1000);
      words += convertLessThanThousand(thousands) + ' Thousand ';
      remaining %= 1000;
    }
    
    // Remaining (< 1000)
    if (remaining > 0) {
      if (words !== '') words += 'and ';
      words += convertLessThanThousand(remaining);
    }
    
    return words.trim() + ' Rupees Only';
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      <ReceptionSidebar />

      <main className="flex-1 p-4 lg:p-8">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Create Bill</h1>
          </div>
          <p className="text-gray-600 ml-13">
            Generate a new transaction/bill for a patient
          </p>
        </div>

        {!showPrintPreview ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            {/* Patient Search Section */}
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">
                Select Patient
              </h2>

              {selectedPatient ? (
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-indigo-500 flex items-center justify-center">
                        <User className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {selectedPatient.personal?.name}
                        </h3>
                        <div className="flex items-center gap-4 mt-1">
                          <span className="text-sm text-gray-600 flex items-center gap-1">
                            <Phone className="w-3 h-3" />
                            {selectedPatient.personal?.phone}
                          </span>
                          <span className="text-sm text-gray-600">
                            {selectedPatient.personal?.branch}
                          </span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => setSelectedPatient(null)}
                      className="p-2 hover:bg-white rounded-lg transition-colors"
                    >
                      <X className="w-5 h-5 text-gray-600" />
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex gap-3 mb-4">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            handleSearchPatient();
                          }
                        }}
                        placeholder="Search by name or phone..."
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                    <button
                      onClick={handleSearchPatient}
                      className="px-6 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg font-medium hover:shadow-lg transition-all"
                    >
                      Search
                    </button>
                  </div>

                  {searchResults.length > 0 && (
                    <div className="border border-gray-200 rounded-lg max-h-64 overflow-y-auto">
                      {searchResults.map((patient) => (
                        <div
                          key={patient._id}
                          onClick={() => handleSelectPatient(patient)}
                          className="p-4 hover:bg-gray-50 cursor-pointer border-b last:border-b-0 transition-colors"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <p className="font-medium text-gray-900">
                                {patient.personal?.name}
                              </p>
                              <div className="flex items-center gap-4 mt-1">
                                <span className="text-sm text-gray-600">
                                  {patient.personal?.phone}
                                </span>
                                <span className="text-sm text-gray-600">
                                  {patient.personal?.branch}
                                </span>
                              </div>
                            </div>
                            <span
                              className={`px-2 py-1 rounded-full text-xs font-medium ${
                                patient.ops?.status === "NEW"
                                  ? "bg-blue-100 text-blue-700"
                                  : "bg-green-100 text-green-700"
                              }`}
                            >
                              {patient.ops?.status}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Bill Details Form */}
            <form onSubmit={handleSubmit}>
              <div className="p-6 space-y-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">
                  Transaction Details
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Payment Method <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={billData.method}
                      onChange={(e) => handleChange("method", e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    >
                      <option value="cash">Cash</option>
                      <option value="upi">UPI</option>
                      <option value="card">Card</option>
                      <option value="banking">Net Banking</option>
                      <option value="Loan">Loan</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Procedure <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={billData.procedure}
                      onChange={(e) => handleChange("procedure", e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    >
                      <option value="hair transplant">Hair Transplant</option>
                      <option value="prp">PRP</option>
                      <option value="beard transplant">Beard Transplant</option>
                      <option value="medicine">Medicine</option>
                      <option value="gfc">GFC</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Payment Type <span className="text-red-500">*</span>
                    </label>
                    <select
                      value={billData.paymentType}
                      onChange={(e) => handleChange("paymentType", e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    >
                      <option value="Booking">Booking</option>
                      <option value="Pending">Pending Payment</option>
                      <option value="Full-payment">Full Payment</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Amount (₹) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      required
                      value={billData.amount}
                      onChange={(e) => handleChange("amount", e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      placeholder="Enter amount"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Date <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="date"
                      value={billData.date}
                      onChange={(e) => handleChange("date", e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Branch
                    </label>
                    <input
                      type="text"
                      value={billData.branch}
                      readOnly
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
                    />
                  </div>

                  <div className="md:col-span-3">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Remarks
                    </label>
                    <textarea
                      value={billData.remarks}
                      onChange={(e) => handleChange("remarks", e.target.value)}
                      rows={3}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                      placeholder="Additional notes..."
                    />
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 rounded-b-xl flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={handleReset}
                  className="px-6 py-2.5 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-100 transition-colors flex items-center gap-2"
                >
                  <X className="w-4 h-4" />
                  Reset
                </button>
                <button
                  type="submit"
                  disabled={loading || !selectedPatient}
                  className="px-6 py-2.5 bg-gradient-to-r from-green-500 to-emerald-500 text-white rounded-lg font-medium hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  {loading ? "Creating..." : "Create Bill"}
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Print Preview Section */
          <div className="space-y-6">
            {/* Print Actions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Bill Created Successfully!</h2>
                <div className="flex gap-3">
                  <button
                    onClick={() => setShowPrintPreview(false)}
                    className="px-6 py-2.5 border border-gray-300 rounded-lg font-medium text-gray-700 hover:bg-gray-100 transition-colors flex items-center gap-2"
                  >
                    <X className="w-4 h-4" />
                    Back to Form
                  </button>
                  <button
                    onClick={printBill}
                    className="px-6 py-2.5 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition-colors flex items-center gap-2"
                  >
                    <Printer className="w-4 h-4" />
                    Print Bill
                  </button>
                  <button
                    onClick={generatePDF}
                    className="px-6 py-2.5 bg-green-500 text-white rounded-lg font-medium hover:bg-green-600 transition-colors flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    Download PDF
                  </button>
                </div>
              </div>
            </div>

            {/* Bill Preview */}
            <div ref={billRef} className="bg-white rounded-xl shadow-lg border-2 border-gray-300 p-8 bill-container">
              {/* Bill Header */}
              <div className="text-center border-b-2 border-gray-400 pb-6 mb-6">
                <h1 className="text-4xl font-bold text-gray-900 mb-3">HAIR CLINIC</h1>
                <p className="text-gray-700 text-lg mb-2">123 Clinic Street, Medical City, Delhi - 110001</p>
                <p className="text-gray-600 mb-1">Phone: +91 9876543210 | Email: info@hairclinic.com</p>
                <p className="text-gray-600 font-medium">GSTIN: 07AABCU9603R1ZM</p>
              </div>

              {/* Bill Title */}
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold text-gray-900">TAX INVOICE</h2>
              </div>

              {/* Bill Details */}
              <div className="grid grid-cols-2 gap-8 mb-6">
                <div className="detail-section">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 border-b pb-2">Patient Details</h3>
                  <div className="space-y-2">
                    <p className="text-gray-700"><strong>Name:</strong> {selectedPatient?.personal?.name}</p>
                    <p className="text-gray-700"><strong>Phone:</strong> {selectedPatient?.personal?.phone}</p>
                    <p className="text-gray-700"><strong>Branch:</strong> {billData.branch}</p>
                  </div>
                </div>
                <div className="detail-section">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 border-b pb-2">Bill Details</h3>
                  <div className="space-y-2">
                    <p className="text-gray-700"><strong>Bill No:</strong> {createdTransaction?._id?.slice(-8).toUpperCase() || "N/A"}</p>
                    <p className="text-gray-700"><strong>Date:</strong> {formatDate(billData.date)}</p>
                    <p className="text-gray-700"><strong>Payment Method:</strong> {billData.method.toUpperCase()}</p>
                  </div>
                </div>
              </div>

              {/* Transaction Details */}
              <div className="detail-section">
                <h3 className="text-lg font-semibold text-gray-900 mb-3 border-b pb-2">Service Details</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center py-3 border-b">
                    <span className="font-medium text-gray-700">Procedure</span>
                    <span className="text-gray-900">{billData.procedure}</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b">
                    <span className="font-medium text-gray-700">Payment Type</span>
                    <span className="text-gray-900">{billData.paymentType}</span>
                  </div>
                  <div className="flex justify-between items-center py-3 border-b">
                    <span className="font-medium text-gray-700">Amount</span>
                    <span className="font-bold text-lg text-gray-900">{formatCurrency(billData.amount)}</span>
                  </div>
                </div>
              </div>

              {/* Remarks */}
              {billData.remarks && (
                <div className="detail-section">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 border-b pb-2">Remarks</h3>
                  <p className="text-gray-700 bg-gray-50 p-4 rounded-lg border">{billData.remarks}</p>
                </div>
              )}

              {/* Total and Signature */}
              <div className="border-t-2 border-gray-400 pt-6 mt-6">
                <div className="flex justify-between items-center mb-2 total-row">
                  <span className="text-xl font-bold text-gray-900">Total Amount:</span>
                  <span className="text-2xl font-bold text-green-600">{formatCurrency(billData.amount)}</span>
                </div>
                
                <div className="text-center mb-4">
                  <p className="text-gray-600">Amount in Words: {convertToWords(billData.amount)}</p>
                </div>

                <div className="signature-section">
                  <div className="signature">
                    <div className="signature-line"></div>
                    <p className="text-sm font-medium mt-2">Patient Signature</p>
                  </div>
                  <div className="signature">
                    <div className="signature-line"></div>
                    <p className="text-sm font-medium mt-2">Authorized Signature</p>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="text-center mt-8 pt-6 border-t border-gray-400">
                <p className="text-gray-600 text-sm">Thank you for choosing our services!</p>
                <p className="text-gray-500 text-xs mt-2">This is a computer generated receipt. No signature required.</p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}