"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Calendar,
  UserPlus,
  Users,
  DollarSign,
  Clock,
  CheckCircle,
  TrendingUp,
  Phone,
} from "lucide-react";
import ReceptionSidebar from "@/components/ReceptionSidebar";
import { useToast } from "@/components/Toast";

export default function ReceptionDashboard() {
  const router = useRouter();
  const toast = useToast();
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    todayAppointments: 0,
    todayVisits: 0,
    pendingAppointments: 0,
    totalPatients: 0,
    todayRevenue: 0,
    recentPatients: [],
    upcomingAppointments: [],
  });

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/reception/dashboard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      
      if (!res.ok) throw new Error("Failed to fetch dashboard data");
      
      const data = await res.json();
      setDashboardData(data);
    } catch (error) {
      console.error("Error:", error);
      toast.error("Failed to load dashboard data");
    } finally {
      setLoading(false);
    }
  };

  const MetricCard = ({ title, value, icon: Icon, color, onClick }) => (
    <div
      onClick={onClick}
      className={`bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all cursor-pointer ${
        onClick ? "hover:scale-105" : ""
      }`}
    >
      <div className="flex items-center justify-between mb-4">
        <div
          className={`w-12 h-12 rounded-lg bg-gradient-to-br ${color} flex items-center justify-center`}
        >
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
      <h3 className="text-2xl font-bold text-gray-900">{value}</h3>
      <p className="text-sm text-gray-600 mt-1">{title}</p>
    </div>
  );

  const QuickAction = ({ title, icon: Icon, color, onClick }) => (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 p-4 rounded-lg bg-gradient-to-r ${color} text-white hover:shadow-lg transition-all`}
    >
      <Icon className="w-5 h-5" />
      <span className="font-medium">{title}</span>
    </button>
  );

  if (loading) {
    return (
      <div className="flex min-h-screen">
        <ReceptionSidebar />
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-gray-50">
      <ReceptionSidebar />

      <main className="flex-1 p-4 lg:p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Reception Dashboard
          </h1>
          <p className="text-gray-600">
            Welcome back! Here's what's happening today.
          </p>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <MetricCard
            title="Today's Appointments"
            value={dashboardData.todayAppointments}
            icon={Calendar}
            color="from-blue-500 to-blue-600"
            onClick={() => router.push("/reception/patients?today=true")}
          />
          <MetricCard
            title="Patients Visited"
            value={dashboardData.todayVisits}
            icon={CheckCircle}
            color="from-green-500 to-green-600"
            onClick={() => router.push("/reception/patients?visited=true")}
          />
          <MetricCard
            title="Pending Appointments"
            value={dashboardData.pendingAppointments}
            icon={Clock}
            color="from-amber-500 to-amber-600"
            onClick={() => router.push("/reception/patients?pending=true")}
          />
          <MetricCard
            title="Today's Revenue"
            value={`₹${dashboardData.todayRevenue.toLocaleString()}`}
            icon={DollarSign}
            color="from-purple-500 to-purple-600"
            onClick={() => router.push("/reception/transactions")}
          />
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <QuickAction
              title="Add New Patient"
              icon={UserPlus}
              color="from-indigo-500 to-indigo-600"
              onClick={() => router.push("/reception/add-patient")}
            />
            <QuickAction
              title="View All Patients"
              icon={Users}
              color="from-blue-500 to-blue-600"
              onClick={() => router.push("/reception/patients")}
            />
            <QuickAction
              title="Create Bill"
              icon={DollarSign}
              color="from-green-500 to-green-600"
              onClick={() => router.push("/reception/create-bill")}
            />
            <QuickAction
              title="Update Patient"
              icon={TrendingUp}
              color="from-purple-500 to-purple-600"
              onClick={() => router.push("/reception/update-patient")}
            />
          </div>
        </div>

        {/* Recent Patients & Upcoming Appointments */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Patients */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              Recent Patients
            </h3>
            <div className="space-y-3">
              {dashboardData.recentPatients.length > 0 ? (
                dashboardData.recentPatients.map((patient) => (
                  <div
                    key={patient._id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors"
                    onClick={() =>
                      router.push(`/reception/patients/${patient._id}`)
                    }
                  >
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">
                        {patient.personal?.name}
                      </p>
                      <div className="flex items-center gap-4 mt-1">
                        <span className="text-xs text-gray-600 flex items-center gap-1">
                          <Phone className="w-3 h-3" />
                          {patient.personal?.phone}
                        </span>
                        <span className="text-xs text-gray-600">
                          {patient.personal?.branch}
                        </span>
                      </div>
                    </div>
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${
                        patient.ops?.status === "NEW"
                          ? "bg-blue-100 text-blue-700"
                          : patient.ops?.status === "CONSULTED"
                          ? "bg-green-100 text-green-700"
                          : "bg-purple-100 text-purple-700"
                      }`}
                    >
                      {patient.ops?.status}
                    </span>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">
                  No recent patients
                </p>
              )}
            </div>
          </div>

          {/* Upcoming Appointments */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-bold text-gray-900 mb-4">
              Upcoming Appointments
            </h3>
            <div className="space-y-3">
              {dashboardData.upcomingAppointments.length > 0 ? (
                dashboardData.upcomingAppointments.map((appointment) => (
                  <div
                    key={appointment._id}
                    className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center">
                      <Calendar className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">
                        {appointment.personal?.name}
                      </p>
                      <p className="text-sm text-gray-600">
                        {new Date(
                          appointment.personal?.visitDate
                        ).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">
                  No upcoming appointments
                </p>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}