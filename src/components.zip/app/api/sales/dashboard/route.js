import { NextResponse } from "next/server";
import { withDB } from "@/lib/withDB";
import Patient from "@/models/Patient";
import Employee from "@/models/Employee";

const VALID_BRANCHES = ["All", "Delhi", "Mumbai", "Hyderabad"];

const handler = async (req) => {
  try {
    const data = await req.json();
    const { branch = "All", from, to } = data;

    // ✅ Validate branch
    if (!VALID_BRANCHES.includes(branch)) {
      return NextResponse.json(
        { error: "Invalid branch specified" },
        { status: 400 }
      );
    }

    // ✅ Date range setup
    const today = new Date();
    const fromDate = from ? new Date(from) : new Date(today);
    fromDate.setHours(0, 0, 0, 0);

    const toDate = to ? new Date(to) : new Date(today);
    toDate.setHours(23, 59, 59, 999);

    if (isNaN(fromDate.getTime()) || isNaN(toDate.getTime())) {
      return NextResponse.json(
        { error: "Invalid date provided" },
        { status: 400 }
      );
    }

    if (fromDate > toDate) {
      return NextResponse.json(
        { error: "From date cannot be after to date" },
        { status: 400 }
      );
    }

    // ✅ Calculate the number of days in the selected range
    const daysDifference = Math.ceil((toDate - fromDate) / (1000 * 60 * 60 * 24)) + 1;

    // ✅ Calculate yesterday's date range (same duration as selected range, but shifted back)
    const yesterdayEnd = new Date(fromDate);
    yesterdayEnd.setDate(yesterdayEnd.getDate() - 1);
    yesterdayEnd.setHours(23, 59, 59, 999);

    const yesterdayStart = new Date(yesterdayEnd);
    yesterdayStart.setDate(yesterdayStart.getDate() - (daysDifference - 1));
    yesterdayStart.setHours(0, 0, 0, 0);

    // ✅ Centralized filter objects
    const branchFilter = branch === "All" ? {} : { "personal.branch": branch };
    const branchFilterEmployee = branch === "All" ? {} : { branch };

    // ✅ OPTIMIZED: Single aggregation for all patient counts (current period & comparison period)
    const getPatientStats = async () => {
      const result = await Patient.aggregate([
        {
          $match: {
            ...branchFilter,
            createdAt: {
              $gte: fromDate,
              $lte: toDate
            }
          },
        },
        {
          $facet: {
            // Current period counts
            totalLeads: [
              { $count: "count" },
            ],
            newPatients: [
              { 
                $match: { 
                  $or: [
                    { "ops.status": "NEW" },
                    { "ops.status": "APPOINTMENT_BOOKED" }
                  ]
                } 
              },
              { $count: "count" },
            ],
            contacted: [
              {
                $match: {
                  "counselling.counsellor": { $exists: true, $ne: "" },
                },
              },
              { $count: "count" },
            ],
            converted: [
              {
                $match: {
                  "counselling.converted": true,
                },
              },
              { $count: "count" },
            ],
            notConverted: [
              {
                $match: {
                  "counselling.counsellor": { $exists: true, $ne: "" },
                  "counselling.converted": false,
                },
              },
              { $count: "count" },
            ],
            revenue: [
              {
                $group: {
                  _id: null,
                  total: { 
                    $sum: { 
                      $convert: {
                        input: "$payments.amountReceived",
                        to: "double",
                        onError: 0
                      }
                    } 
                  }
                }
              }
            ],
          },
        },
      ]);

      // Comparison period stats
      const comparisonResult = await Patient.aggregate([
        {
          $match: {
            ...branchFilter,
            createdAt: {
              $gte: yesterdayStart,
              $lte: yesterdayEnd
            }
          },
        },
        {
          $facet: {
            totalLeads: [{ $count: "count" }],
            newPatients: [
              { 
                $match: { 
                  $or: [
                    { "ops.status": "NEW" },
                    { "ops.status": "APPOINTMENT_BOOKED" }
                  ]
                } 
              },
              { $count: "count" },
            ],
            contacted: [
              { $match: { "counselling.counsellor": { $exists: true, $ne: "" } } },
              { $count: "count" },
            ],
            converted: [
              { $match: { "counselling.converted": true } },
              { $count: "count" },
            ],
            revenue: [
              {
                $group: {
                  _id: null,
                  total: { 
                    $sum: { 
                      $convert: {
                        input: "$payments.amountReceived",
                        to: "double",
                        onError: 0
                      }
                    } 
                  }
                }
              }
            ],
          },
        },
      ]);

      return {
        current: {
          totalLeads: result[0]?.totalLeads[0]?.count || 0,
          newPatients: result[0]?.newPatients[0]?.count || 0,
          contacted: result[0]?.contacted[0]?.count || 0,
          converted: result[0]?.converted[0]?.count || 0,
          notConverted: result[0]?.notConverted[0]?.count || 0,
          revenue: result[0]?.revenue[0]?.total || 0,
        },
        comparison: {
          totalLeads: comparisonResult[0]?.totalLeads[0]?.count || 0,
          newPatients: comparisonResult[0]?.newPatients[0]?.count || 0,
          contacted: comparisonResult[0]?.contacted[0]?.count || 0,
          converted: comparisonResult[0]?.converted[0]?.count || 0,
          revenue: comparisonResult[0]?.revenue[0]?.total || 0,
        },
      };
    };

    // ✅ OPTIMIZED: Agent performance aggregation
    const getAgentPerformance = async () => {
      const result = await Employee.aggregate([
        {
          $match: {
            ...branchFilterEmployee,
            role: { $regex: 'agent', $options: 'i' }
          }
        },
        {
          $lookup: {
            from: "patients",
            localField: "_id",
            foreignField: "personal.reference",
            as: "patients"
          }
        },
        {
          $project: {
            name: 1,
            phone: 1,
            branch: 1,
            totalLeads: {
              $size: {
                $filter: {
                  input: "$patients",
                  as: "patient",
                  cond: {
                    $and: [
                      { $gte: ["$$patient.createdAt", fromDate] },
                      { $lte: ["$$patient.createdAt", toDate] }
                    ]
                  }
                }
              }
            },
            converted: {
              $size: {
                $filter: {
                  input: "$patients",
                  as: "patient",
                  cond: {
                    $and: [
                      { $gte: ["$$patient.createdAt", fromDate] },
                      { $lte: ["$$patient.createdAt", toDate] },
                      { $eq: ["$$patient.counselling.converted", true] }
                    ]
                  }
                }
              }
            }
          }
        },
        {
          $addFields: {
            conversionRate: {
              $cond: {
                if: { $gt: ["$totalLeads", 0] },
                then: { $multiply: [{ $divide: ["$converted", "$totalLeads"] }, 100] },
                else: 0
              }
            }
          }
        },
        {
          $match: {
            totalLeads: { $gt: 0 }
          }
        },
        {
          $sort: { conversionRate: -1 }
        },
        {
          $limit: 10
        }
      ]);

      return result.map(agent => ({
        name: agent.name,
        phone: agent.phone,
        branch: agent.branch,
        totalLeads: agent.totalLeads,
        converted: agent.converted,
        conversionRate: Math.round(agent.conversionRate * 100) / 100
      }));
    };

    // ✅ Get active agents count
    const getActiveAgents = async () => {
      const result = await Employee.countDocuments({
        ...branchFilterEmployee,
        role: { $regex: 'agent', $options: 'i' }
      });
      return result;
    };

    // ✅ Execute all aggregations in parallel
    const [patientStats, agentPerformance, activeAgents] = await Promise.all([
      getPatientStats(),
      getAgentPerformance(),
      getActiveAgents(),
    ]);

    // ✅ Calculate growth percentage (trends)
    const calculateGrowth = (current, comparison) => {
      if (comparison === 0) return current > 0 ? "+100%" : "0%";
      const change = ((current - comparison) / comparison) * 100;
      const roundedChange = Math.round(change);
      return `${roundedChange >= 0 ? '+' : ''}${roundedChange}%`;
    };

    // ✅ Prepare final response
    return NextResponse.json({
      success: true,
      data: {
        totalLeads: patientStats.current.totalLeads,
        newPatients: patientStats.current.newPatients,
        contacted: patientStats.current.contacted,
        converted: patientStats.current.converted,
        notConverted: patientStats.current.notConverted,
        revenue: patientStats.current.revenue,
        activeAgents: activeAgents,
        agentPerformance: agentPerformance,
        trends: {
          totalLeads: calculateGrowth(patientStats.current.totalLeads, patientStats.comparison.totalLeads),
          newPatients: calculateGrowth(patientStats.current.newPatients, patientStats.comparison.newPatients),
          contacted: calculateGrowth(patientStats.current.contacted, patientStats.comparison.contacted),
          converted: calculateGrowth(patientStats.current.converted, patientStats.comparison.converted),
          revenue: calculateGrowth(patientStats.current.revenue, patientStats.comparison.revenue),
        },
        dateRange: {
          from: fromDate.toISOString().split("T")[0],
          to: toDate.toISOString().split("T")[0],
          comparisonPeriod: {
            from: yesterdayStart.toISOString().split("T")[0],
            to: yesterdayEnd.toISOString().split("T")[0],
          },
        },
        branch,
      }
    });

  } catch (error) {
    console.error("Sales dashboard error:", error);
    return NextResponse.json(
      { 
        success: false,
        error: "Internal server error", 
        details: error.message 
      },
      { status: 500 }
    );
  }
};

export const POST = withDB(handler);