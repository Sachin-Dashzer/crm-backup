import { NextResponse } from "next/server";
import { withDB } from "@/lib/withDB";
import Patient from "@/models/Patient";
import Transactions from "@/models/Transactions";

const handler = async (req) => {
  try {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    // Get today's appointments
    const todayAppointments = await Patient.countDocuments({
      "personal.visitDate": {
        $gte: today,
        $lt: tomorrow,
      },
    });

    // Get today's visits (patients who have been counselled)
    const todayVisits = await Patient.countDocuments({
      "personal.visitDate": {
        $gte: today,
        $lt: tomorrow,
      },
      "counselling.counsellor": { $exists: true, $ne: null },
    });

    // Get pending appointments (patients with NEW status)
    const pendingAppointments = await Patient.countDocuments({
      "ops.status": "NEW",
    });

    // Get total patients
    const totalPatients = await Patient.countDocuments();

    // Get today's revenue
    const todayRevenueData = await Transactions.aggregate([
      {
        $match: {
          costType: "Revenue",
          date: {
            $gte: today,
            $lt: tomorrow,
          },
        },
      },
      {
        $group: {
          _id: null,
          total: { $sum: "$amount" },
        },
      },
    ]);

    const todayRevenue = todayRevenueData[0]?.total || 0;

    // Get recent patients (last 5)
    const recentPatients = await Patient.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .select("personal ops");

    // Get upcoming appointments (next 5 days)
    const fiveDaysLater = new Date(today);
    fiveDaysLater.setDate(fiveDaysLater.getDate() + 5);

    const upcomingAppointments = await Patient.find({
      "personal.visitDate": {
        $gte: today,
        $lte: fiveDaysLater,
      },
    })
      .sort({ "personal.visitDate": 1 })
      .limit(5)
      .select("personal");

    return NextResponse.json({
      todayAppointments,
      todayVisits,
      pendingAppointments,
      totalPatients,
      todayRevenue,
      recentPatients,
      upcomingAppointments,
    });
  } catch (error) {
    console.error("Dashboard error:", error);
    return NextResponse.json(
      { error: "Internal server error", details: error.message },
      { status: 500 }
    );
  }
};

export const POST = withDB(handler);