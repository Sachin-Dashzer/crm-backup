import { NextResponse } from "next/server";
import { withDB } from "@/lib/withDB";
import Patient from "@/models/Patient";
import Employee from "@/models/Employee";
import mongoose from "mongoose";

const handler = async (req) => {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        {
          success: false,
          error: "Patient ID is required",
        },
        { status: 400 }
      );
    }

    const patient = await Patient.findById(id);
    if (!patient) {
      return NextResponse.json({ error: "Patient not found" }, { status: 404 });
    }
    const data = await req.json();

    // Check for duplicate phone number
    if (
      data.personal?.phone &&
      data.personal.phone !== patient.personal.phone
    ) {
      const numberExisted = await Patient.findOne({
        "personal.phone": data.personal.phone,
      });

      if (numberExisted) {
        return NextResponse.json(
          { error: "Phone number already exists" },
          { status: 400 }
        );
      }
    }

    // Get the original patient data to compare reference changes
    const originalPatient = await Patient.findById(id);

    const updatedPatient = await Patient.findByIdAndUpdate(
      id,
      { $set: data },
      { new: true, runValidators: true }
    )
      .populate("personal.reference")
      .populate("counselling.counsellor")
      .populate("surgery.doctor")
      .populate("surgery.seniorTech")
      .populate("surgery.implanterRight")
      .populate("surgery.implanterLeft")
      .populate("surgery.graftingPerson")
      .populate("surgery.helper")
      .populate("payments.transactions");

    // Handle employee reference updates
    const employeeUpdatePromises = [];

    // Helper function to add employee update promise
    const addEmployeeUpdate = (employeeId, fieldName, operation) => {
      if (employeeId && mongoose.Types.ObjectId.isValid(employeeId)) {
        const updateOperation =
          operation === "add"
            ? { $addToSet: { patient: data._id } } // Use addToSet to avoid duplicates
            : { $pull: { patient: data._id } };

        employeeUpdatePromises.push(
          Employee.findByIdAndUpdate(employeeId, updateOperation, {
            new: true,
          }).catch((error) => {
            console.error(
              `Error updating employee ${fieldName} with ID ${employeeId}:`,
              error
            );
            return null; // Don't fail other updates if one fails
          })
        );
      }
    };

    // Check for reference changes and update employees accordingly
    if (
      data.personal?.reference !==
      originalPatient.personal?.reference?.toString()
    ) {
      // Remove from old reference employee
      if (originalPatient.personal?.reference) {
        addEmployeeUpdate(
          originalPatient.personal.reference,
          "reference",
          "remove"
        );
      }
      // Add to new reference employee
      if (data.personal?.reference) {
        addEmployeeUpdate(data.personal.reference, "reference", "add");
      }
    }

    // Check counselling counsellor changes
    if (
      data.counselling?.counsellor !==
      originalPatient.counselling?.counsellor?.toString()
    ) {
      if (originalPatient.counselling?.counsellor) {
        addEmployeeUpdate(
          originalPatient.counselling.counsellor,
          "counsellor",
          "remove"
        );
      }
      if (data.counselling?.counsellor) {
        addEmployeeUpdate(data.counselling.counsellor, "counsellor", "add");
      }
    }

    // Check surgery team changes
    if (data.surgery) {
      const surgeryFields = [
        "doctor",
        "seniorTech",
        "implanterRight",
        "implanterLeft",
        "graftingPerson",
        "helper",
      ];

      surgeryFields.forEach((field) => {
        const newValue = data.surgery[field];
        const oldValue = originalPatient.surgery?.[field];

        if (newValue !== oldValue?.toString()) {
          // Remove from old employee
          if (oldValue) {
            addEmployeeUpdate(oldValue, field, "remove");
          }
          // Add to new employee
          if (newValue) {
            addEmployeeUpdate(newValue, field, "add");
          }
        }
      });
    }

    // Execute all employee updates in parallel
    if (employeeUpdatePromises.length > 0) {
      await Promise.all(employeeUpdatePromises);
      console.log(
        `Updated ${employeeUpdatePromises.length} employee records for patient reference changes`
      );
    }

    return NextResponse.json(
      {
        success: true,
        message: `Patient updated successfully and ${employeeUpdatePromises.length} employee records updated`,
        data: updatedPatient,
      },
      { status: 200 }
    );
  } catch (error) {
    console.error("Error updating patient:", error);
    return NextResponse.json(
      { error: "Internal Server Error", details: error.message },
      { status: 500 }
    );
  }
};

export const PUT = withDB(handler);
