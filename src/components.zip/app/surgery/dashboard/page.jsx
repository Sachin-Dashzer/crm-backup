
"use client";

import { useState, useEffect } from "react";
import { Stethoscope, Calendar, CheckCircle, Clock } from "lucide-react";
import Sidebar from "@/components/SurgerySidebar";
import Topbar from "@/components/Topbar";
import MetricCard from "@/components/MetricCard";

export default function SurgeryDashboard() {
  const [loading, setLoading] = useState(true);
  const [dashboardData, setDashboardData] = useState(null);
  const [branch, setBranch] = useState("All");
  const [dateRange, setDateRange] = useState("Today");

  useEffect(() => {
    fetchData();
  }, [branch, dateRange]);

  const fetchData = async () => {
    setLoading(true);
    try {
      setDashboardData({
        scheduledSurgeries: 6,
        completedSurgeries: 4,
        pendingSurgeries: 2,
        readyForSurgery: 8,
      });
    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  const metrics = [
    { title: "Scheduled Surgeries", value: dashboardData?.scheduledSurgeries || 0, icon: Calendar, color: "from-blue-500 to-blue-600" },
    { title: "Completed Today", value: dashboardData?.completedSurgeries || 0, icon: CheckCircle, color: "from-green-500 to-green-600" },
    { title: "Pending", value: dashboardData?.pendingSurgeries || 0, icon: Clock, color: "from-amber-500 to-amber-600" },
    { title: "Ready for Surgery", value: dashboardData?.readyForSurgery || 0, icon: Stethoscope, color: "from-indigo-500 to-indigo-600" },
  ];

  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar role="surgery" />
      <main className="flex-1 p-4 lg:p-8">
        <Topbar 
          role="surgery"
          timeRange={dateRange}
          setTimeRange={setDateRange}
          branch={branch}
          setBranch={setBranch}
        />
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {metrics.map((card, idx) => (
              <MetricCard key={idx} {...card} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
