
"use client";

import { useState } from "react";
import Sidebar from "@/components/SurgerySidebar";
import Topbar from "@/components/Topbar";
import { Stethoscope } from "lucide-react";

export default function SurgeryPatientsPage() {
  return (
    <div className="flex min-h-screen bg-gray-50">
      <Sidebar role="surgery" />
      <main className="flex-1 p-4 lg:p-8">
        <Topbar role="surgery" />
        <div className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-2xl font-bold flex items-center gap-2 mb-6">
            <Stethoscope className="w-6 h-6" />
            Surgery Patients
          </h2>
          <div className="text-center py-12 text-gray-500">
            Surgery patient list
          </div>
        </div>
      </main>
    </div>
  );
}
