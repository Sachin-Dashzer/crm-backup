import mongoose from "mongoose";

const patientSchema = new mongoose.Schema(
  {
    personal: {
      name: String,
      phone: {
        type: String,
        unique: true,
      },
      email: String,
      age: Number,
      gender: {
        type: String,
        enum: ["MALE", "FEMALE", "OTHERS"],
      },
      branch: {
        type: String,
        enum: ["Delhi", "Mumbai", "Hyderabad"],
      },
      address: String,
      profession: String,
      visitDate: Date,
      reference: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
      },
      packageQuoted: Number,
      techniqueQuoted: String,
      remarks: String,
    },
    counselling: {
      counsellor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
      },
      techniqueSuggested: {
        type: String,
        enum: ["FUE", "INDIAN DHI", "DHI", "HYBRID", "PRP", "GFC", "Other"],
      },
      finlpackage: Number,
      graftsSuggested: Number,
      readyForSurgery: { type: Boolean, default: false },
      notes: String,
      additionalbenefits: [String],
      medicines: [String],
      hairlossType: String,
      areaofConcern: String,
      hairlossreason: String,
      hairlossduration: String,
    },
    medical: {
      allergies: String,
      medicalHistory: {
        type: String,
        enum: ["YES", "NO", "UNKNOWN"],
      },
      bloodGroup: {
        type: String,
        enum: ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
      },
      sugar: String,
      bp: String,
      pulse: String,
      weight: String,
      hiv: String,
      hcv: String,
    },
    surgery: {
      surgeryDate: Date,
      location: {
        type: String,
      },
      OT: Number,
      technique: {
        type: String,
      },
      graftsneed: Number,
      graftsImplanted: Number,
      donorCondition: String,
      doctor: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
      },
      seniorTech: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
      },
      implanterRight: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
      },
      implanterLeft: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
      },
      graftingPerson: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
      },
      helper: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Employee",
      },
    },
    payments: {
      amountReceived: { type: Number, default: 0 },
      pendingAmount: { type: Number, default: 0 },
      medicineAmount: { type: Number, default: 0 },
      totalAmount: { type: Number, default: 0 }, // Make sure this exists
      transactions: [
        { type: mongoose.Schema.Types.ObjectId, ref: "Transactions" },
      ],
    },

    documents: {
      images: [String],
      consentForm: [String],
      suregeryForm: [String],
      consultForm: [String],
    },
    ops: {
      status: {
        type: String,
        enum: ["NEW", "CONSULTED", "SURGERY_BOOKED", "CLOSED"],
        default: "NEW",
      },
    },
  },
  { timestamps: true }
);

export default mongoose.models.Patient ||
  mongoose.model("Patient", patientSchema);
