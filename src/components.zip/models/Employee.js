import mongoose from 'mongoose';

const employeeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Name is required'],
    trim: true
  },
  phone: {
    type: String,
    required: [true, 'Phone is required'],
    trim: true
  },
  email: {
    type: String,
    trim: true,
    lowercase: true
  },
  role: {
    type: String,
    required: [true, 'Role is required'],
    enum : ["Agent", "Counsellor" , "Doctor" , "Technician" , "Implanter" , "Others"],
    trim: true
  },
  patient: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "Patient"  }]
}, {
  timestamps: true
});


export default mongoose.models.Employee || mongoose.model('Employee', employeeSchema);